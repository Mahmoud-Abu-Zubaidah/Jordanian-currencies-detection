# Money Classifier #2 > 2024-02-19 1:33am
https://universe.roboflow.com/classifier-zclul/money-classifier-2

Provided by a Roboflow user
License: CC BY 4.0

